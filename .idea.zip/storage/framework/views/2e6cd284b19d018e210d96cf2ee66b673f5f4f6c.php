

<?php $__env->startSection('content'); ?>
<main>
  <div class="property-list-view">
    <div class="row">
      <div class="col-md-7 col-sm-12">
        <div class="list-view-top d-flex justify-content-between">
          <div class="w-75">
            <h5 class="list-view-hdr">
              <?php if($searchedProperty): ?>
              <span class="font-weight-bold">
                <?php echo e($properties->total()); ?> homes available in Nep-Estate Listed below
              </span>
              <?php else: ?>
                No homes available with the keyword " <span class="text-info"><?php echo e(request()->property); ?></span> " <br>
                You can see other Available homes below
              <?php endif; ?></h5>
            <hr>
            <p class="list-view-text text-info">
              Homes for Sale near '<?php echo e($properties->first()->address); ?>'
            </p>
          </div>
          <div class="form-group">
            <form action="<?php echo e(route('property.priceChanger')); ?>" method="POST">
              <select name="list-type" class="form-control" onchange="this.form.submit()" >
                <option value="0">Just for you</option>
                <option value="1">Price low to high</option>
                <option value="2">Price high to low</option>
              </select>
              <input type="hidden" name="keyword" value="<?php echo e(request()->property); ?>">
              <?php echo csrf_field(); ?>
            </form>
          </div>
        </div>
        <div class="property-list">
          <div class="row">
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-sm-6">
              <div class="property-card" >
                <img src="<?php echo e(asset($property->img_url)); ?>" alt="" class="img-fluid">
                <div class="property-card-body border">
                  <a href="<?php echo e($property->path()); ?>">
                    <h5 class="property-price badge badge-info">$<?php echo e(number_format($property->price)); ?></h5>
                    <div class="d-flex my-2">
                      <div class="badge badge-secondary"><i class="fas fa-bed"></i> <?php echo e($property->bed); ?> beds</div>
                      <div class="badge badge-secondary mx-2"><i class="fas fa-bath"></i> <?php echo e($property->bath); ?> baths</div>
                      <div class="badge badge-secondary"><i class="fas fa-mountain"></i> <?php echo e($property->area); ?> sqft</div>
                    </div>
                    <p class="property-name"><?php echo e($property->name); ?></p>
                    <p class="text-muted property-address"><?php echo e($property->address); ?></p>
                  </a>
                  <a href="<?php echo e($property->path()); ?>" class="btn btn-block primary-btn">Check Availability</a>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
          </div>
        </div>
        <div class="list-view-paginator">
          <ul class="link-list">

            <?php if($paginator->hasPages()): ?>
              <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $elem => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($data); ?>" class="link-list-item <?php echo e($elem == $paginator->currentPage() ? 'current-page': ''); ?>">
                  <p class="link"><?php echo e($elem); ?></p>
                </a>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <li class="link-list-item">
              <a href="<?php echo e(url()->current()); ?>" class="">1</a>
              </li>
            <?php endif; ?>
            
            <li class="link-list-item">
              <a href="<?php echo e(end($properties->render()->elements[0])); ?>"><i class="fas fa-angle-right"></i></a>
            </li>
          </ul>
          <p class="total-pagination"><?php echo e($properties->render()->paginator->total()); ?> Results</p>
        </div>
        <div class="list-footer">
          <p class="list-footer-text">Zillow Group is committed to ensuring digital accessibility for individuals with
            disabilities. We are continuously working to improve the accessibility of our web experience for
            everyone, and we welcome feedback and accommodation requests. If you wish to report an issue or seek an
            accommodation, please <a href="#">contact us.</a></p>
          <p class="list-footer-text mt-4">
            Copyright © 2020 Trulia, LLC. All rights reserved. Equal Housing Opportunity. Have a Question? Visit our
            Help Center to find the answer.
          </p>
        </div>
      </div><!-- property list -->
      <div class="col-md-5 col-sm-12">
        <div class="google-map" id="google-map">
          <div class="mapouter">
            <div class="gmap_canvas"><iframe width="500" height="500" id="gmap_canvas"
                src="https://maps.google.com/maps?ll=27.7172453,85.3239605&q=Kathmandu&t=&z=14&ie=UTF8&iwloc=&output=embed"
                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div>
            <style>
              .google-map{
                width:100%;
              }
              .mapouter {
                position: relative;
                text-align: right;
                height: 500px;
                width: 100%;
              }

              .gmap_canvas {
                overflow: hidden;
                background: none !important;
                height: 100%;
                width: 100%;
              }
            </style>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script>

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.list-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\nepestate\resources\views/real-estate/property/list.blade.php ENDPATH**/ ?>