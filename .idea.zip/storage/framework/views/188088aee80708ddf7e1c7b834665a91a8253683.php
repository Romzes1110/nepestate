<nav class="navbar navbar-expand-md navbar-light bg-light shadow" id="navbar">
  <a href="<?php echo e(route('property.index')); ?>" class="navbar-brand">
    <!-- <img src="logo2.png" alt="">-->CyberEsate</a>
  <div class="navbar-search-bx">
    <form action="<?php echo e(route('property.search')); ?>" method="GET">
      <input type="text" placeholder="Псков" name="property" class="navbar-search-input">
      <button type="submit" class="primary-btn"><i class="fas fa-search"></i></button>
    </form>
  </div>
  <ul class="navbar-nav mr-auto">
    <li class="nav-item"><a href="<?php echo e(route('property.buy')); ?>" class="nav-link">Купить</a></li>
    <li class="nav-item"><a href="<?php echo e(route('property.rent')); ?>" class="nav-link">Снять</a></li>
    <li class="nav-item"><a href="<?php echo e(route('property.mortage')); ?>" class="nav-link">Ипотека</a></li>
  </ul>
  <ul class="navbar-nav mx-auto">
    <li class="nav-item"><a href="<?php echo e(route('page','saved-homes')); ?>" class="nav-link">Сохранённые дома</a></li>
    <li class="nav-item"><a href="<?php echo e(route('page','rental-resume')); ?>" class="nav-link">История аренды</a></li>
  </ul>
  <ul class="navbar-nav ml-auto">
    <?php if(auth()->guard()->check()): ?>
    <li class="nav-item dropdown">
      <a href="<?php echo e(route('user.login')); ?>" class="primary-btn dropdown-toggle" data-toggle="dropdown">Вы вошли как <?php echo e(auth()->user()->name); ?></a>
      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="notificationDropdown">
        <a class="dropdown-item" href="<?php echo e(route('page','user-profile')); ?>">
          <span class="dropdown-link" >Аккаунт пользователя</span>
        </a>
        <a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>">
          <span class="dropdown-link" >Выход</span>
        </a>
      </div>
    </li>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
    <a href="<?php echo e(route('user.login')); ?>" class="primary-btn">Регистрация / Вход</a>
    <?php endif; ?>
  </ul>
  <div class="mb-nav">
    <a href="#" class="nav-link mb-nav-toggler"><i class="fas fa-bars"></i></a>
    <div class="mb-nav-list">
      <a href="#" class="mb-nav-toggler ml-auto btn btn-danger text-light">Закрыть </a>
      <a href="<?php echo e(route('user.login')); ?>" class="mb-nav-link">Регистрация / Вход</a>
      <a href="<?php echo e(route('property.buy')); ?>" class="mb-nav-link">Купить <i class="fas fa-angle-down"></i></a>
      <a href="<?php echo e(route('property.rent')); ?>" class="mb-nav-link">Снять <i class="fas fa-angle-down"></i></a>
      <a href="<?php echo e(route('property.mortage')); ?>" class="mb-nav-link">Ипотека <i class="fas fa-angle-down"></i></a>
    </div>
  </div>
</nav>
<?php /**PATH W:\domains\nepestate\resources\views/inc/navbar.blade.php ENDPATH**/ ?>