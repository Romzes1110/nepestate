
@extends('layouts.app')
@section('layout-holder')
    @yield('content')
@endsection